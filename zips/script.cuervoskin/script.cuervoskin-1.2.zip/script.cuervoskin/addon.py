
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,random,urllib2,urllib,glob,re
from resources import tools

ADDON_ID       = 'script.diggzskins'
fanart         = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
icon           = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,      'addons')
USERDATA       = os.path.join(HOME,      'userdata')
ADDOND         = os.path.join(USERDATA,  'addon_data')
DIALOG         = xbmcgui.Dialog()
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
repositoryurl = 'http://grumpeh.hemera.feralhosting.com/repo/_repo/'
repositoryxml = 'http://grumpeh.hemera.feralhosting.com/repo/_repo/addons.xml'

#### Icons Kodi 17 Style #################
AeonNoxSilvo        = xbmc.translatePath(os.path.join('https://archive.org/download/batmanbase/aeon.png'))
Eminence            = xbmc.translatePath(os.path.join('https://archive.org/download/batmanbase/eminen.png'))
xonfluence          = xbmc.translatePath(os.path.join('special://home/media/0/conflu.png'))
Urban_Essence       = xbmc.translatePath(os.path.join('special://home/addons/skin.urbanessence/icon.png'))
Twilight            = xbmc.translatePath(os.path.join('special://home/addons/skin.twilight/icon.png'))
The_Vault           = xbmc.translatePath(os.path.join('special://home/addons/skin.thevault/icon.png'))
Semplice            = xbmc.translatePath(os.path.join('special://home/addons/skin.fuse.neue/icon.png'))
Appetizer           = xbmc.translatePath(os.path.join('special://home/addons/skin.andromeda/icon.png'))
X1                  = xbmc.translatePath(os.path.join('special://home/addons/skin.diggzx1/icon.png'))
Diggz_Kids          = xbmc.translatePath(os.path.join('special://home/addons/skin.diggzkids/icon.png'))
Aurora              = xbmc.translatePath(os.path.join('special://home/addons/skin.aurora/icon.png'))
Xenon_Real_Debrid   = xbmc.translatePath(os.path.join('special://home/addons/skin.xenonrd/icon.png'))
Diggz_1_Click       = xbmc.translatePath(os.path.join('special://home/addons/skin.1klik/icon.png'))
Diggz_XenoX         = xbmc.translatePath(os.path.join('special://home/addons/skin.xenon2/icon.png'))

#### Icons Kodi 18 Style #########
AeonNoxSilvo               = xbmc.translatePath(os.path.join('special://home/media/0/aeonnox.png'))
Eminence            = xbmc.translatePath(os.path.join('special://home/media/0/sinwidgets.png'))
EminenceFull          = xbmc.translatePath(os.path.join('special://home/media/0/conwidgets.png')) 


def MainMenu():
	addItem('Current Skin -- %s' % currSkin(),'url','',icon,fanart,'')
	addItem('Click here to change skins ','url',1,icon,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.aeon.nox.silvojan)'):
		addItem('AeonNoxSilvo','url',2,AeonNoxSilvo,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.eminence.2)'):
		addItem('Eminence','url',3,Eminence,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.xonfluence.18)'):
		addItem('xonfluence','url',4,xonfluence,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.urbanessence)'):
		addItem('Urban Essence','url',5,Urban_Essence,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.twilight)'):
		addItem('Twilight','url',6,Twilight,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.thevault)'):
		addItem('The Vault','url',7,The_Vault,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.fuse.neue)'):
		addItem('Semplice','url',8,Semplice,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.andromeda)'):
		addItem('Appetizer Menu','url',9,Appetizer,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.diggzx1)'):
		addItem('X1','url',10,X1,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.diggzkids)'):
		addItem('Diggz Kids','url',11,Diggz_Kids,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.aurora)'):
		addItem('Aurora','url',12,Aurora,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.xenonrd)'):
		addItem('cuervo Real Debrid','url',13,Xenon_Real_Debrid,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.1klik)'):
		addItem('Diggz 1 Click','url',14,Diggz_XenoX,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.xenon2)'):
		addItem('Diggz XenoX','url',15,Diggz_XenoX,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.thevault18)'):
		addItem('The Vault-LEIA','url',16,The_Vault_LEIA,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(skin.jansolo18)'):
		addItem('cuervo-LEIA','url',17,Xenon_LEIA,fanart,'')
	if xbmc.getCondVisibility('System.HasAddon(sskin.diggzxxx18)'):
		addItem('Dirty Chef XXX-LEIA','url',18,Dirty_Chef_XXX_LEIA,fanart,'')
	
#Example how to add more Skins
#addItem('Skin Name','url',5,icon,fanart,'') The number will be the mode at the bottom
#addItem('Skin Name','url',6,icon,fanart,'') The number will be the mode at the bottom

def skinWIN():
	idle()
	fold = glob.glob(os.path.join(ADDONS, 'skin*'))
	name = []; addonids = []
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			match  = tools.parseDOM(a, 'addon', ret='id')
			addid  = foldername if len(match) == 0 else match[0]
			try: 
				add = xbmcaddon.Addon(id=addid)
				name.append(add.getAddonInfo('name'))
				addonids.append(addid)
			except:
				pass
	selected = []; choice = 0
	skin = ["Current Skin -- %s" % currSkin()] + name
	choice = DIALOG.select("Choose a flavor.", skin)
	if choice == -1: return
	else: 
		choice1 = (choice-1)
		selected.append(choice1)
		skin[choice] = "%s" % ( name[choice1])
	if selected == None: return
	for addon in selected:
		swapSkins(name,addonids[addon])

def Skin_install(name,skin):
	popup = DIALOG.yesno('Diggz Skins', "In order to use this build you must install the %s skin."% name,"Do you want to install it?" , yeslabel="[B][COLOR springgreen]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No[/COLOR][/B]")
	if popup == 1:
		ver = tools.parseDOM(tools.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': skin})
		if len(ver) > 0:
			skinzip = '%s/%s/%s-%s.zip' % (repositoryurl, skin, skin, ver[0])
			if KODIV >= 17: tools.addonDatabase(skin, 1)
			tools.installAddon(skin, skinzip)
			xbmc.executebuiltin('UpdateAddonRepos()')
			swapSkins(name,skin)
			sys.exit(0)			
	else:return

def currSkin():
	skiname = xbmc.getSkinDir('Container.PluginName')
	skiname = xbmcaddon.Addon(skiname).getAddonInfo('name')
	return skiname

def swapSkins(name,skin, title="Error"):
	if not xbmc.getCondVisibility('System.HasAddon('+skin+')'):
		Skin_install(name,skin)
	else:
		old = 'lookandfeel.skin'
		value = skin
		current = getOld(old)
		new = old
		setNew(new, value)
		x = 0
		while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
			x += 1
			xbmc.sleep(100)
		if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
			xbmc.executebuiltin('SendClick(11)')
		sys.exit(0)

def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None

def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)
		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None

def idle():
	return xbmc.executebuiltin('Dialog.Close(busydialog)')

def addItem(name, url, mode, iconimage, fanart, description=None):
	if description == None: description = ''
	description = '[COLOR white]' + description + '[/COLOR]'
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param

params=get_params(); name=None; url=None; mode=None; iconimage=None; fanartimage=None
try: name=urllib.unquote_plus(params["name"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanartimage=urllib.quote_plus(params["fanartimage"])
except: pass

if mode is None or url is None or len(url)<1: 
	MainMenu()#change to skinWIN() to open select window automaticly
elif mode==1:skinWIN()
elif mode==2:swapSkins(name,'skin.aeon.nox.silvojan')
elif mode==3:swapSkins(name,'skin.eminence.2')
elif mode==4:swapSkins(name,'skin.xonfluence.18')
elif mode==5:swapSkins(name,'skin.urbanessence')
elif mode==6:swapSkins(name,'skin.twilight')
elif mode==7:swapSkins(name,'skin.thevault')
elif mode==8:swapSkins(name,'skin.fuse.neue')
elif mode==9:swapSkins(name,'skin.andromeda')
elif mode==10:swapSkins(name,'skin.diggzx1')
elif mode==11:swapSkins(name,'skin.diggzkids')
elif mode==12:swapSkins(name,'skin.aurora')
elif mode==13:swapSkins(name,'skin.xenonrd')
elif mode==14:swapSkins(name,'skin.1klik')
elif mode==15:swapSkins(name,'skin.xenon2')
elif mode==16:swapSkins(name,'skin.thevault18')
elif mode==17:swapSkins(name,'skin.jansolo18')
elif mode==18:swapSkins(name,'skin.diggzxxx18')
elif mode==19:swapSkins(name,'skin.skin.xonfluence')


# How to add more modes 
#elif mode==4:swapSkins(name,'Exact skin folder')
#elif mode==5:swapSkins(name,'Exact skin folder')
xbmcplugin.endOfDirectory(int(sys.argv[1]))

